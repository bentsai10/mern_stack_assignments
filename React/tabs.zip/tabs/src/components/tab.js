import React, {useState} from 'react';

const Tab = ({title, content, text, setText}) =>{
    const [checkedState, setCheckedState] = useState(false)
    const [tabStyle, setTabStyle] = useState({
        backgroundColor: 'lightgray',
        color: 'black',
        display: "block",
        marginTop: 10,
        marginRight:10,
    });
    const checkClicked = (e) => {
        e.preventDefault();
        if(checkedState){
            console.log("I'm in if");
            setTabStyle({
                backgroundColor: 'lightgray',
                color: 'black',
                display: "block",
                marginTop: 10,
                marginRight:10,
            });
        }else{
            console.log("I'm in else");
            setTabStyle({
                backgroundColor: 'black',
                color: 'white',
                display: "block",
                marginTop: 10,
                marginRight:10,
            });
            setText(content);
            console.log(text);
        }
        setCheckedState(!checkedState);
    }
    return <div>
        <button onClick = {checkClicked} style = {tabStyle}>{title}</button>
    </div>
}

export default Tab;
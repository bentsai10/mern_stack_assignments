import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello Dojo!</h1>
      <h2>Things I Need to Do!</h2>
      <ol>
        <li>Watch the Lakers win the 2020 NBA Finals</li>
        <li>Watch the 49ers win the 2021 Super Bowl</li>
        <li>Watch Tottenham win the 2020-21 Premier League</li>
        <li>Watch Duke win the 2021 NCAA Championship</li>
        <li>Watch the Giants win the 2020 World Series</li>
      </ol>
    </div>
  );
}

export default App;
